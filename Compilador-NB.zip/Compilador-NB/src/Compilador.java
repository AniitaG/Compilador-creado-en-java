
import com.formdev.flatlaf.FlatIntelliJLaf;
import compilerTools.CodeBlock;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import compilerTools.Directory;
import compilerTools.ErrorLSSL;
import compilerTools.Functions;
import compilerTools.Grammar;
import compilerTools.Production;
import compilerTools.TextColor;
import compilerTools.Token;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author Ana Gomez
 */
public class Compilador extends javax.swing.JFrame {

    private String title;
    private Directory directorio;
    private ArrayList<Token> tokens;
    private ArrayList<ErrorLSSL> errors;
    private ArrayList<TextColor> textsColor;
    private Timer timerKeyReleased;
    private ArrayList<Production> identProd;
    private HashMap<String, String> identificadores;
    private boolean codeHasBeenCompiled = false;

    /**
     * Creates new form Compilador
     */
    public Compilador() {
        initComponents();
        init();
    }

    private void init() {
        title = "Trabajo Final de la materia de Lenguaje y Automatas II: Compilador - Ana Paula Gomez Gomez";
        setLocationRelativeTo(null);
        setTitle(title);
        directorio = new Directory(this, jtpCode, title, ".comp");
        addWindowListener(new WindowAdapter() {// Cuando presiona la "X" de la esquina superior derecha
            @Override
            public void windowClosing(WindowEvent e) {
                directorio.Exit();
                System.exit(0);
            }
        }
        );
        Functions.setLineNumberOnJTextComponent(jtpCode);
        timerKeyReleased = new Timer((int) (1000 * 0.3), (ActionEvent e) -> {
            timerKeyReleased.stop();
            colorAnalysis();
        }
        );
        Functions.insertAsteriskInName(this, jtpCode, () -> {
            timerKeyReleased.restart();
        }
        );
        tokens = new ArrayList<>();
        errors = new ArrayList<>();
        textsColor = new ArrayList<>();
        identProd = new ArrayList<>();
        identificadores = new HashMap<>();
        Functions.setAutocompleterJTextComponent(new String[]{"color", "numero", "Norte", "Sur",
            "Este", "Oeste", "arriba", "abajo", "centrar", "acomodar", "Trabajo final", "Letras"}, jtpCode, () -> {
            timerKeyReleased.restart();
        }
        );
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rootPanel = new javax.swing.JPanel();
        buttonsFilePanel = new javax.swing.JPanel();
        btnAbrir = new javax.swing.JButton();
        btnNuevo = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtpCode = new javax.swing.JTextPane();
        panelButtonCompilerExecute = new javax.swing.JPanel();
        btnCompilar = new javax.swing.JButton();
        btnEjecutar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jtaOutputConsole = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblTokens = new javax.swing.JTable();
        btnGuardarC = new javax.swing.JButton();
        btnGuardar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        getContentPane().setLayout(new javax.swing.BoxLayout(getContentPane(), javax.swing.BoxLayout.LINE_AXIS));

        rootPanel.setBackground(new java.awt.Color(153, 0, 204));
        rootPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        buttonsFilePanel.setBackground(new java.awt.Color(153, 0, 204));
        buttonsFilePanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnAbrir.setBackground(new java.awt.Color(255, 255, 255));
        btnAbrir.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/Icon/icons8_opened_folder_48px.png"))); // NOI18N
        btnAbrir.setText("Abrir");
        btnAbrir.setToolTipText("Abrir Documento");
        btnAbrir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnAbrir.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/pressed/icons8_opened_folder_48px_P.png"))); // NOI18N
        btnAbrir.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/On Layer/icons8_opened_folder_48px_ON.png"))); // NOI18N
        btnAbrir.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirActionPerformed(evt);
            }
        });
        buttonsFilePanel.add(btnAbrir, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 90, 90));

        btnNuevo.setBackground(new java.awt.Color(255, 255, 255));
        btnNuevo.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/Icon/icons8_code_file_48px.png"))); // NOI18N
        btnNuevo.setText("Nuevo");
        btnNuevo.setToolTipText("Crear Nuevo Documento");
        btnNuevo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnNuevo.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/pressed/icons8_code_file_48px_p.png"))); // NOI18N
        btnNuevo.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/On Layer/icons8_code_file_48px_on.png"))); // NOI18N
        btnNuevo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });
        buttonsFilePanel.add(btnNuevo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 80, 90));

        rootPanel.add(buttonsFilePanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 11, -1, -1));

        jtpCode.setBorder(javax.swing.BorderFactory.createCompoundBorder(javax.swing.BorderFactory.createCompoundBorder(), javax.swing.BorderFactory.createCompoundBorder()));
        jtpCode.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jScrollPane1.setViewportView(jtpCode);

        rootPanel.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 693, 170));

        panelButtonCompilerExecute.setBackground(new java.awt.Color(153, 0, 204));
        panelButtonCompilerExecute.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnCompilar.setBackground(new java.awt.Color(255, 255, 255));
        btnCompilar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnCompilar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/Icon/icons8_code_48px.png"))); // NOI18N
        btnCompilar.setText("Compilar");
        btnCompilar.setToolTipText("Compilar");
        btnCompilar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnCompilar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/pressed/icons8_code_48px_p.png"))); // NOI18N
        btnCompilar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/On Layer/icons8_code_48px_on.png"))); // NOI18N
        btnCompilar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnCompilar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCompilarActionPerformed(evt);
            }
        });
        panelButtonCompilerExecute.add(btnCompilar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 100, 90));

        btnEjecutar.setBackground(new java.awt.Color(255, 255, 255));
        btnEjecutar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEjecutar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/Icon/icons8-index-48.png"))); // NOI18N
        btnEjecutar.setText("Ejecutar");
        btnEjecutar.setToolTipText("Ejecutar");
        btnEjecutar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnEjecutar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/pressed/icons8-index-48.png"))); // NOI18N
        btnEjecutar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/On Layer/icons8-index-48.png"))); // NOI18N
        btnEjecutar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnEjecutar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEjecutarActionPerformed(evt);
            }
        });
        panelButtonCompilerExecute.add(btnEjecutar, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 0, 100, 90));

        rootPanel.add(panelButtonCompilerExecute, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 10, 220, 90));

        jtaOutputConsole.setEditable(false);
        jtaOutputConsole.setColumns(20);
        jtaOutputConsole.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        jtaOutputConsole.setForeground(new java.awt.Color(102, 0, 102));
        jtaOutputConsole.setRows(5);
        jScrollPane2.setViewportView(jtaOutputConsole);

        rootPanel.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 288, 693, -1));

        tblTokens.setBackground(new java.awt.Color(153, 153, 255));
        tblTokens.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        tblTokens.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tblTokens.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Componente léxico", "Lexema", "[Línea, Columna]"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tblTokens);

        rootPanel.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(715, 67, 405, 317));

        btnGuardarC.setBackground(new java.awt.Color(255, 255, 255));
        btnGuardarC.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnGuardarC.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/pressed/icons8_save_48px_p.png"))); // NOI18N
        btnGuardarC.setText("Guardar como");
        btnGuardarC.setToolTipText("Guardar Documento como");
        btnGuardarC.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardarC.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/Icon/icons8_save_close_48px.png"))); // NOI18N
        btnGuardarC.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/Icon/icons8_save_close_48px.png"))); // NOI18N
        btnGuardarC.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarCActionPerformed(evt);
            }
        });
        rootPanel.add(btnGuardarC, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 110, 90));

        btnGuardar.setBackground(new java.awt.Color(255, 255, 255));
        btnGuardar.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnGuardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/On Layer/icons8_save_48px_on.png"))); // NOI18N
        btnGuardar.setText("Guardar");
        btnGuardar.setToolTipText("Guardar Documento");
        btnGuardar.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnGuardar.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/pressed/icons8_save_48px_p.png"))); // NOI18N
        btnGuardar.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/iconos/Icon/icons8_save_48px.png"))); // NOI18N
        btnGuardar.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });
        rootPanel.add(btnGuardar, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 10, 100, 90));

        getContentPane().add(rootPanel);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        directorio.New();
        clearFields();
    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirActionPerformed
        if (directorio.Open()) {
            colorAnalysis();
            clearFields();
        }
    }//GEN-LAST:event_btnAbrirActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        if (directorio.Save()) {
            clearFields();
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnGuardarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarCActionPerformed
        if (directorio.SaveAs()) {
            clearFields();
        }
    }//GEN-LAST:event_btnGuardarCActionPerformed

    private void btnCompilarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCompilarActionPerformed
        if (getTitle().contains("*") || getTitle().equals(title)) {
            if (directorio.Save()) {
                compile();
            }
        } else {
            compile();
        }
    }//GEN-LAST:event_btnCompilarActionPerformed

    private void btnEjecutarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEjecutarActionPerformed
        btnCompilar.doClick();
        if (codeHasBeenCompiled) {
            if (!errors.isEmpty()) {
                JOptionPane.showMessageDialog(null, "No se logro ejecutar el codigo debido a que se encontraron errores, revisa los textos ingresados",
                        "Error en la compilación", JOptionPane.ERROR_MESSAGE);
            } else {
                CodeBlock codeBlock = Functions.splitCodeInCodeBlocks(tokens, "{", "}", ";");
                System.out.println(codeBlock);
                ArrayList<String> blocksOfCode = codeBlock.getBlocksOfCodeInOrderOfExec();
                System.out.println(blocksOfCode);

            }
        }
    }//GEN-LAST:event_btnEjecutarActionPerformed

    private void compile() {
        clearFields();
        lexicalAnalysis();
        fillTableTokens();
        syntacticAnalysis();
        semanticAnalysis();
        printConsole();
        codeHasBeenCompiled = true;
    }

    private void lexicalAnalysis() {
        // Extraer tokens
        Lexer lexer;
        try {
            File codigo = new File("code.encrypter");
            FileOutputStream output = new FileOutputStream(codigo);
            byte[] bytesText = jtpCode.getText().getBytes();
            output.write(bytesText);
            BufferedReader entrada = new BufferedReader(new InputStreamReader(new FileInputStream(codigo), "UTF8"));
            lexer = new Lexer(entrada);
            while (true) {
                Token token = lexer.yylex();
                if (token == null) {
                    break;
                }
                tokens.add(token);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("El archivo no pudo ser encontrado... " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("Error al escribir en el archivo... " + ex.getMessage());
        }
    }

    private void syntacticAnalysis() {
        Grammar gramatica = new Grammar(tokens, errors);
        /*Eliminacion de errores*/
        gramatica.delete(new String[]{"ERROR", "ERROR_1", "ERROR_2"}, 1);

        /*Agrupacion de valores*/
        gramatica.group("VALOR", "(NUMERO|COLOR)", true);
        /*Declaracion de variables*/
        gramatica.group("VARIABLE", "TIPO_DATO IDENTIFICADOR OP_ASIG VALOR", true, identProd );
        gramatica.group("VARIABLE", "TIPO_DATO OP_ASIG VALOR", true,
                2, "error sintactico: falta el identificador en la variable[#,%]");

        gramatica.finalLineColumn();

        gramatica.group("VARIABLE", "TIPO_DATO IDENTIFICADOR OP_ASIG", 3,
                "error sintactico{}:falta el valor en la declaracion");
        gramatica.initialLineColumn();

        /*Eliminacion de tipo de datos y operadores de asignacion*/
        gramatica.delete("TIPO_DE_DATO", 4,
                "ERROR SINTACTICO{}:el tipo de dato no esta en una declaracion{#,%}");
        gramatica.delete("OP_ASIG", 5,
                "ERROR SINTACTICO{}:el operador de asignacion no esta en una declaracion{#,%}");

        /*Agrupaciones de identificadores y definicion de parametros*/
        gramatica.group("VALOR", "IDENTIFICADOR", true);
        gramatica.group("PARAMETROS", "VALOR(COMA VALOR)+");

        /*Agrupacion de funciones*/
        gramatica.group("FUNCION", "(MOVIMIENTO|COLOREAR|Sombrear Pintar|Lanzar"
                + "Deslizar Objeto|INSTRUCCIONES|Detener repetir", true);
        gramatica.group("FUNCION_COMP", "FUNCION PARENTESIS_A(VALOR|PARAMETROS)? PARENTECIS_C", true);
        gramatica.group("FUNCION_COMP", "FUNCION(VALOR|PARAMETROS)? PARENTECIS_C", true,
                6, "error sintactico {}: falta el parentesis que abre en la funcion{#,%}");
        gramatica.finalLineColumn();

        gramatica.group("FUNCION_COMP", "FUNCION PARENTESIS_A(VALOR|PARAMETROS)", true,
                7, "error sintactico {}: falta el parentesis que abre en la funcion{#,%}");
        gramatica.initialLineColumn();

        /*Eliminacion de funciones incompletas*/
        gramatica.delete("FUNCION", 8, "ERROR SINTACTICO {}: LA FUNCION NO ESTA DECLARADA CORRECTAMENTE");

        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            gramatica.group("EXP_LOGICA", "FUNCION_COMP | EXP_LOGICA (OP_LOGICO FUNCION_COMP | EXP_LOGICA))+");
            gramatica.group("EXP_LOGICA", "PARENTESIS_A (EXP_LOGICA | FUNCION_COMP) PARENTESIS_C");
        });
        /*Eliminacion de operadores logicos*/
        gramatica.delete("OP_LOGICO", 10, "error sintactico {}: el operador logico no esta contenido en una exprecion");
        /*Agrupacion dee exp. logicas como valor y parametro*/
        gramatica.group("VALOR", "EXP_LOGICA");
        gramatica.group("PARAMETROS", "VALOR(COMA VALOR)+");

        /*AGRUPACION DE ESTRUCTURAS DE CONTROL*/
        gramatica.group("EST_CONTROL", "(REPETIR |ESTRUCTURA_SI)");
        gramatica.group("EST_CONTROL_COM", "EST_CONTROL PARENTESIS_A PARENTESIS_C");
        gramatica.group("EST_control", "EST_CONTROL (VALOR|PARAMETROS)");
        gramatica.group("EST_CONTROL_COMP", "EST_CONTROL PARENTESIS_A (VALOR | PARAMETROS) PARENTESIS_C");

        /*ELIMINACION DE ESTRUCTURAS INCOMPLETAS*/
        gramatica.delete("EST_CONTROL", 11,
                "error sintactico {}:la estructura de control no esta declarada corectamente[#,%]");
        /*ELIMINACION DE PARENTESIS*/
        gramatica.delete(new String[]{"PARENTESIS_A", "PARENTESIS_C"}, 12,
                "error sintactico {}: el parentesis [] no esta contenido en una agrupacion [#,%]");
        gramatica.finalLineColumn();
        /*VERIFICACION DE PUNTO Y COMA AL FINAL DE UNA SENTENCIA*/
        //IDENTIFICADORES O VARIABLES//
        gramatica.group("VARIABLE_PC", "VARIABLE PUNTO_COMA", true);
        gramatica.group("VARIABLE_PC", "VARIABLE", true,
                13, "error sintactico {}: falta el punto y coma al final de la variable");
        //FUNCIONES
        gramatica.group("FUNCION_COMP_PC", "FUNCION_COMP PUNTO_COMA");
        gramatica.group("FUNCION_COMP_PC", "FUNCION_COMP", 14,
                "error sintactico {}: falta el punto y coma al final de la claracion de la funcion ");

        gramatica.initialLineColumn();

        /*ELIMINACION DE PUNTO Y COMA*/
        gramatica.delete("PUNTO_COMMA", 15, "error sintactico {}: el punto y coma no esta al final de una sentencia");
        /*SENTENCIAS*/
        gramatica.group("SENTENCIAS", "(VARIABLE_PC|FUNCION_COMP_PC)+");

        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            gramatica.group("EST_CONTROL_COMP_LASLC", "EST_CONTROL_COMP LLAVE_A SENTENCIAS");
            gramatica.group("SENTENCIAS", "(SENTENCIAS| EST_CONTROL_COMP_LASLC)+");
        });
        /*ESTRUCTURAS DE FUNCION INCOMPLETAS*/
        gramatica.loopForFunExecUntilChangeNotDetected(() -> {
            gramatica.group("EST_CONTROL_LASLC", "EST_CONTROL_COMP(SENTENCIAS)? LLAVE_C", true,
                    15, "error sintactico{}: falta la llave que abre en la estructura de control");
            gramatica.finalLineColumn();

            gramatica.group("EST_CONTROL_COMP_LASLC", "EST_CONTROL_COMP LLAVE_A SENTENCIAS", true,
                    15, "error sintactico {}: falta la llaveque abre la estructura de control");
            gramatica.group("SENTENCIAS", "(SENTENCIAS| EST_CONTROL_COMP_LASLC)");
        });
        gramatica.delete(new String[]{"LLAVE_A", "LLAVE_C"}, 16,
                "error sintactico{}: la llave{} no esta contenida en una agrupacion[#,%]"
        );
        

        /* Mostrar gramáticas */
        gramatica.show();

    }

    private void semanticAnalysis() {
        for(Production id: identProd){
        System.out.println(id.lexemeRank(0, -1));
        System.out.println("*");
        
        }
    }

    private void colorAnalysis() {
        /* Limpiar el arreglo de colores */
        textsColor.clear();
        /* Extraer rangos de colores */
        LexerColor lexerColor;
        try {
            File codigo = new File("color.encrypter");
            FileOutputStream output = new FileOutputStream(codigo);
            byte[] bytesText = jtpCode.getText().getBytes();
            output.write(bytesText);
            BufferedReader entrada = new BufferedReader(new InputStreamReader(new FileInputStream(codigo), "UTF8"));
            lexerColor = new LexerColor(entrada);
            while (true) {
                TextColor textColor = lexerColor.yylex();
                if (textColor == null) {
                    break;
                }
                textsColor.add(textColor);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("El archivo no pudo ser encontrado... " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("Error al escribir en el archivo... " + ex.getMessage());
        }
        Functions.colorTextPane(textsColor, jtpCode, new Color(40, 40, 40));
    }

    private void fillTableTokens() {
        tokens.forEach(token -> {
            Object[] data = new Object[]{token.getLexicalComp(), token.getLexeme(), "[" + token.getLine() + ", " + token.getColumn() + "]"};
            Functions.addRowDataInTable(tblTokens, data);
        });
    }

    private void printConsole() {
        int sizeErrors = errors.size();
        if (sizeErrors > 0) {
            Functions.sortErrorsByLineAndColumn(errors);
            String strErrors = "\n";
            for (ErrorLSSL error : errors) {
                String strError = String.valueOf(error);
                strErrors += strError + "\n";
            }
            jtaOutputConsole.setText("Compilación finalizada...\n" + strErrors + "\nLa compilación finalizo con errores...");
        } else {
            jtaOutputConsole.setText("Compilación finalizada...");
        }
        jtaOutputConsole.setCaretPosition(0);
    }

    private void clearFields() {
        Functions.clearDataInTable(tblTokens);
        jtaOutputConsole.setText("");
        tokens.clear();
        errors.clear();
        identProd.clear();
        identificadores.clear();
        codeHasBeenCompiled = false;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Compilador.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(new FlatIntelliJLaf());
            } catch (UnsupportedLookAndFeelException ex) {
                System.out.println("LookAndFeel no soportado: " + ex);
            }
            new Compilador().setVisible(true);
        }
        );
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrir;
    private javax.swing.JButton btnCompilar;
    private javax.swing.JButton btnEjecutar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnGuardarC;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JPanel buttonsFilePanel;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jtaOutputConsole;
    private javax.swing.JTextPane jtpCode;
    private javax.swing.JPanel panelButtonCompilerExecute;
    private javax.swing.JPanel rootPanel;
    private javax.swing.JTable tblTokens;
    // End of variables declaration//GEN-END:variables
}
